<?php

namespace App\Http\Controllers\Api\v1\Auth;

use App\Http\Controllers\Controller;

class EmailVerificationNotificationController extends Controller
{
    public function __invoke()
    {
        // TODO: Implement __invoke() method.
    }
}
