<?php

namespace App\Http\Controllers\Api\Authentication;

use App\Http\Controllers\Controller;
use App\Services\Api\Authentication\LoginService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Vyuldashev\LaravelOpenApi\Attributes as OpenApi;


#[OpenApi\PathItem]
class LoginController extends Controller
{
    /**
     * Request a Sanctum token for a user.
     *
     * @throws \Exception
     */
    #[OpenApi\Operation(tags: ['Authorization'])]
    public function __invoke(Request $request, LoginService $service)
    {
        try {
            $data = $request->validate([
                'email' => 'required|email',
                'password' => 'required',
            ]);

            return $service($data);

        } catch (HttpException $e) {
            return response()->json([
                'errors' => [
                    [
                        'title' => 'Oops!, algo salió mal.',
                        'detail' => $e->getMessage(),
                    ],
                ],
            ], $e->getStatusCode());
        }
    }
}
