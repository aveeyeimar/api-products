<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\Authentication;


use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Hash;
use Vyuldashev\LaravelOpenApi\Attributes as OpenApi;


#[OpenApi\PathItem]
class NewPasswordController
{
//    /**
//     * Reset the user's password.
//     * @param NewPasswordRequest $request
//     * @param UpdatePasswordUser $updateUserPassword
//     * @return JsonResponse
//     */
//    #[OpenApi\Operation(tags: ['Authorization'])]
//    public function __invoke(NewPasswordRequest $request, UpdatePasswordUser $updateUserPassword): JsonResponse
//    {
//        $updateUserPassword($request, Hash::make($request->get('password')));
//
//        return response()->json([
//            'message' => 'Password updated successfully',
//        ]);
//    }
//}
}
