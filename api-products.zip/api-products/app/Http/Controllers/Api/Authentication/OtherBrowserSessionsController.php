<?php

namespace App\Http\Controllers\Api\Authentication;

use App\Http\Controllers\Controller;
use App\Models\Users\Session;
use Illuminate\Http\Request;

class OtherBrowserSessionsController extends Controller
{
    /**
     * Handle the incoming request.
     */
    public function index(Request $request)
    {
        $sessions = Session::query()
            ->where('user_id', $request->user()->getAuthIdentifier())
            ->orderBy('last_activity', 'desc')
            ->get();

        return response()->json($sessions);
    }

    public function destroy(Request $request)
    {
        //
    }
}
