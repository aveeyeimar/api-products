<?php

namespace App\Http\Controllers\Api\Authentication;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Auth\PasswordResetLinkRequest;
use App\Notifications\ResetPasswordNotification;
use App\Services\Api\v1\Auth\AddPasswordResetToken;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Str;
use Vyuldashev\LaravelOpenApi\Attributes as OpenApi;


#[OpenApi\PathItem]
class PasswordResetLinkController extends Controller
{

    /**
     * Send a password reset link to the user.
     */

//    #[OpenApi\Operation(tags: ['Authorization'])]
//    public function __invoke(PasswordResetLinkRequest $request, AddPasswordResetToken $resetTokenAction): JsonResponse
//    {
//
//        $user = $request->getSaveUser();
//        $token = Str::random(60);
//        $resetTokenAction($user, $token);
//
//        $user->notify(new ResetPasswordNotification($token));
//
//        return response()->json([
//            'success' => true,
//            'message' => 'Password reset link sent successfully',
//        ]);
//    }
}
