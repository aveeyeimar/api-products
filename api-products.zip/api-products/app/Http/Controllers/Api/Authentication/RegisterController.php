<?php

namespace App\Http\Controllers\Api\Authentication;

use App\Http\Controllers\Controller;
use App\Http\Requests\CreateUserRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Vyuldashev\LaravelOpenApi\Attributes as OpenApi;


#[OpenApi\PathItem]
class RegisterController extends Controller
{
    /**
     * Register a new user.
     *
     * @throws \Exception
     */

    #[OpenApi\Operation(tags: ['Authorization'])]
    public function __invoke(CreateUserRequest $request)
    {
        try {

            $user = User::query()->create([
                'first_name' => $request->validated('first_name'),
                'last_name' => $request->validated('last_name'),
                'email' => $request->validated('email'),
                'password' => Hash::make($request->validated('password')),
            ]);

            if ($user) {
                return response()->json([
                    'message' => 'User created successfully',
                ], 201);
            }


        } catch (\Exception $e) {
            return response()->json([
                'errors' => [
                    [
                        'title' => 'Oops!, algo salió mal.',
                        'detail' => $e->getMessage(),
                    ],
                ],
            ], 400);
        }

    }
}
