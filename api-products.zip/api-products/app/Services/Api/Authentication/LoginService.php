<?php

namespace App\Services\Api\Authentication;

use App\Models\User;
use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\Auth;

class LoginService
{
    /**
     * @throws \Exception
     */
    public function __invoke(array $data): array
    {
        $user = Auth::attempt([
            'email' => $data['email'],
            'password' => $data['password'],
        ]);

        if (!$user) {
            abort(401, 'Credenciales incorrectas');
        }

        return $this->tokenResponse(Auth::user());

    }

    private function tokenResponse(User $user): array
    {
        $token = $user->createToken(name: 'authToken');

        return [
            'token' => $token->plainTextToken,
            'token_type' => 'Bearer',
            'token_expire_at' => $token->accessToken->expires_at,
        ];
    }


}
