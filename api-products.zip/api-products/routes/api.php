<?php


use App\Http\Controllers\Api\Authentication\LoginController;
use App\Http\Controllers\Api\Authentication\LogoutController;
use App\Http\Controllers\Api\Authentication\RegisterController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\UsersController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


Route::prefix('auth')
    ->group(function () {
        Route::post('login', LoginController::class)
            ->name('auth.login');
        Route::post('register', RegisterController::class)
            ->name('auth.register');

        Route::post('logout', LogoutController::class)
            ->middleware('auth:sanctum')
            ->name('auth.logout');
//
//        Route::post('forgot-password', PasswordResetLinkController::class)
//            ->name('auth.forgot-password');
//
//        Route::post('reset-password', NewPasswordController::class)
//            ->name('auth.reset-password');

    });


Route::apiResource('users', UsersController::class)
    ->parameters(['users' => 'user_id'])
    ->middleware('auth:sanctum');


